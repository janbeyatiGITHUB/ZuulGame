
/**
 * Item class models items contained inside instances of Room
 *
 * @author Thomas Poirier
 * @version June 17, 2022
 */
public class Item
{
    private String description;
    private double weight;

    /**
     * Constructor for objects of class Item
     * @param description The description of the item
     * @param weight The weight of the item
     */
    public Item(String description, double weight)
    {
        this.description = description;
        this.weight = weight;
    }

    /**
     * Returns a string representation of the item containing its 
     * description and weight
     * 
     * @return  A description of the item
     */
    public String getItemDetails()
    {
        return description + " weighs " + weight + " kg";
    }
}

